# Air_quality_sensor_v1.3
This is the library for the Air_Quality_Sensor_v1.3 from SeedStudio, this will be compatible with the EspHome Open-Source website
